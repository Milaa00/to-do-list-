// script.js

// Wait until page fully loads
document.addEventListener("DOMContentLoaded", function () {
  const addBtn = document.getElementById("addBtn");
  const taskInput = document.getElementById("taskInput");
  const taskList = document.getElementById("taskList");

  addBtn.addEventListener("click", function () {
    const taskText = taskInput.value.trim();
    if (taskText === "") return;

    const li = document.createElement("li");
    li.textContent = taskText;

    // Toggle completed class on click
    li.addEventListener("click", function () {
      li.classList.toggle("completed");
    });

    // Right-click to delete
    li.addEventListener("contextmenu", function (e) {
      e.preventDefault();
      li.remove();
    });

    taskList.appendChild(li);
    taskInput.value = "";
  });
});
